import json
import openai

class OpenAIService:
    def __init__(self, api_key) -> None:
         self.api_key = api_key

    def openAIPost(self, conv):
        openai.api_key = self.api_key    
        res = openai.Completion.create(
            model="text-davinci-003",
            prompt=conv.getModelInput2(),
            temperature=0.9,
            max_tokens=250,
            top_p=1,
            frequency_penalty=0,
            presence_penalty=0.6,
            stop=[f"{conv.user}:", f"{conv.conversee}:"]
        )
        resText = res["choices"][0]["text"]

        while resText[0] == " " or resText[0] == '\n': resText = resText[1:]
        return resText
        
openai_key = "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"

class Conversation:
    def __init__(self, user, conversee, dia:list, dialogue = []):
        self.dialogue = dialogue
        self.user = user
        self.dia = dia
        self.conversee = conversee

        if not dialogue: 
            initialText = f"The following is a conversation between {user} and {conversee}. Frame responses as {conversee}"
            self.dialogue = [initialText]

    def getModelInput2(self):
        res = f"The following is a conversation between {self.user} and {self.conversee}. Frame responses as {self.conversee}\n"
        for i in range(len(self.dia)):
            res += f"{self.dia[i]['name']}: "
            res += f"{self.dia[i]['text']}\n"

        res += f"{self.conversee}: "
    
        return res
    
    def getModelInput3(self):
        res = [{"role": "system", 
                "content": f"You are {self.conversee}, the 18th century American statesmen, inventor, and diplomat. Frame all answers as he would say them. You are having a conversation with {self.user}, a 21 year old American student."},
        ]
        for i in range(len(self.dia)):
            if self.dia[i]['name']==self.conversee:
                res.append({"role": "assistant", 
                            "content": self.dia[i]['text']})
            elif self.dia[i]['name']==self.user:
                res.append({"role": "user", 
                            "content": self.dia[i]['text']})

        return res

def lambda_handler(event, context):
    # TODO implement
    openAIService = OpenAIService(openai_key)
    #b = json.loads(event.get("body", ""))
    user = event.get("user", "")
    conversee = event.get("conversee", "")
    conversation = event.get("conversation", [])
    
    c = Conversation(user, conversee, conversation)
    
    return {
        "statusCode": 200,
        "res": openAIService.openAIPost(c)
    }